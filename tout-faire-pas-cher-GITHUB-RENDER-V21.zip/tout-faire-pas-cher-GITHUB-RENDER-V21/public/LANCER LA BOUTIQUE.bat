@echo off
setlocal EnableExtensions
set "HERE=%~dp0"
cd /d "%HERE%"

rem Si le lanceur a ete copie/deplace dans public, remonter d'un dossier.
if exist "%HERE%package.json" goto ROOT_OK
if exist "%HERE%..\package.json" (
  cd /d "%HERE%.."
  goto ROOT_OK
)
if exist "%HERE%..\..\package.json" (
  cd /d "%HERE%..\.."
  goto ROOT_OK
)

echo.
echo ERREUR : impossible de trouver package.json.
echo Ce lanceur doit etre dans le dossier principal ou dans le dossier public.
echo.
pause
exit /b 1

:ROOT_OK
set "ROOT=%CD%"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js n'est pas installe.
  echo Installe la version LTS depuis https://nodejs.org/ puis relance ce fichier.
  echo.
  pause
  exit /b 1
)
if not exist "%ROOT%\server.js" (
  echo ERREUR : server.js introuvable dans :
  echo %ROOT%
  pause
  exit /b 1
)
if not exist "%ROOT%\node_modules" (
  echo Installation des composants, une seule fois...
  call npm install
  if errorlevel 1 (
    echo.
    echo ECHEC de npm install.
    pause
    exit /b 1
  )
)

echo.
echo ================================================
echo   TOUT FAIRE PAS CHER ? OUI ON PEUT !
echo   BOUTIQUE V16
echo ================================================
echo.
echo Ouverture de la boutique...
echo Ne ferme pas cette fenetre.
echo.
start "" "http://localhost:3000/"
node "%ROOT%\server.js"
echo.
echo Le serveur s'est arrete.
pause
