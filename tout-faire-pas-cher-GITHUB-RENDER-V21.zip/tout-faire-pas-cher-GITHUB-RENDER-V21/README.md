# Tout faire pas cher ? Oui on peut ! — V21

Version V21 : panier sans pseudo au moment de l'ajout, 2 comptes admin maximum, catalogue modifiable depuis l'admin, ruptures de stock, promotions visuelles et bannières d'accueil.

## Lancer en local

```bash
npm install
npm start
```
Puis ouvrir http://localhost:3000

## Admin

Ouvrir /admin. Les deux premiers comptes créés deviennent les deux seuls administrateurs. Les deux ont les mêmes droits. Après le deuxième compte, la création est verrouillée.

## Important hébergement

Les fichiers du dossier `data/` contiennent les données modifiables. Sur un hébergeur à système de fichiers éphémère, ces données peuvent être perdues après redéploiement/redémarrage. Pour une vraie boutique 24/7, connecter ensuite une base de données persistante.

Excel n'est plus utilisé par V21.
